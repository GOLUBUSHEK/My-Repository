const STORAGE_KEY = "schoolDiaryDemo_v1";

const seed = {
  users: [
    {id:1,name:"Анна Смирнова",role:"student",login:"student",password:"demo123",className:"8А"},
    {id:2,name:"Иван Петров",role:"teacher",login:"teacher",password:"demo123",subject:"Математика"},
    {id:3,name:"Елена Смирнова",role:"parent",login:"parent",password:"demo123",childId:1},
    {id:4,name:"Администратор",role:"admin",login:"admin",password:"demo123"}
  ],
  grades:[
    {id:1,studentId:1,subject:"Математика",value:5,topic:"Квадратные уравнения",date:"2026-10-29"},
    {id:2,studentId:1,subject:"Русский язык",value:4,topic:"Причастный оборот",date:"2026-10-28"},
    {id:3,studentId:1,subject:"История",value:5,topic:"Эпоха Петра I",date:"2026-10-27"},
    {id:4,studentId:1,subject:"Физика",value:4,topic:"Сила и движение",date:"2026-10-26"},
    {id:5,studentId:1,subject:"Английский язык",value:5,topic:"Present Perfect",date:"2026-10-24"}
  ],
  homework:[
    {id:1,subject:"Математика",title:"Упражнения № 214–216",due:"2026-11-04",status:"В работе"},
    {id:2,subject:"История",title:"Прочитать § 12 и ответить на вопросы",due:"2026-11-05",status:"Не начато"},
    {id:3,subject:"Английский язык",title:"Выучить 15 новых слов",due:"2026-11-06",status:"В работе"}
  ],
  schedule:[
    {id:1,day:"Понедельник",time:"08:30",subject:"Математика",room:"204",teacher:"Иван Петров"},
    {id:2,day:"Понедельник",time:"09:25",subject:"Русский язык",room:"118",teacher:"Мария Иванова"},
    {id:3,day:"Понедельник",time:"10:25",subject:"История",room:"302",teacher:"Олег Соколов"},
    {id:4,day:"Понедельник",time:"11:20",subject:"Физика",room:"215",teacher:"Наталья Орлова"},
    {id:5,day:"Понедельник",time:"12:15",subject:"Английский язык",room:"106",teacher:"Анна Ким"}
  ],
  attendance:[
    {id:1,date:"2026-10-29",subject:"Математика",status:"Присутствовал"},
    {id:2,date:"2026-10-28",subject:"Русский язык",status:"Присутствовал"},
    {id:3,date:"2026-10-27",subject:"История",status:"Опоздание"},
    {id:4,date:"2026-10-26",subject:"Физика",status:"Присутствовал"}
  ]
};

let db = loadDB();
let currentUser = null;
let currentView = "overview";

const roleNames = {student:"Ученик",teacher:"Учитель",parent:"Родитель",admin:"Администратор"};
const viewNames = {overview:"Обзор",grades:"Оценки",homework:"Домашние задания",schedule:"Расписание",attendance:"Посещаемость",users:"Пользователи"};

function loadDB(){
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || structuredClone(seed); }
  catch { return JSON.parse(JSON.stringify(seed)); }
}
function saveDB(){ localStorage.setItem(STORAGE_KEY,JSON.stringify(db)); }
function studentIdForUser(user){ return user.role==="parent" ? user.childId : user.id; }
function studentName(id){ return db.users.find(u=>u.id===id)?.name || "Ученик"; }
function esc(value){ return String(value ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function fmtDate(date){ if(!date) return "—"; return new Date(date+"T12:00:00").toLocaleDateString("ru-RU",{day:"numeric",month:"short"}); }
function average(grades){ return grades.length ? (grades.reduce((s,g)=>s+Number(g.value),0)/grades.length).toFixed(1) : "—"; }
function initials(name){ return name.split(" ").map(x=>x[0]).slice(0,2).join("").toUpperCase(); }

function showLogin(){
  document.body.innerHTML = `
  <main class="login-screen"><section class="login-card">
    <a class="brand"><span class="brand-mark">Д</span><span>Дневник<span class="brand-dot">.</span></span></a>
    <div class="eyebrow">ШКОЛЬНЫЙ ПОРТАЛ</div><h1>С возвращением!</h1>
    <p>Войдите в демонстрационный электронный дневник, чтобы посмотреть оценки, расписание и задания.</p>
    <form id="loginForm">
      <div class="field"><label for="login">Логин</label><input id="login" name="login" placeholder="Например, student" required autocomplete="username"></div>
      <div class="field"><label for="password">Пароль</label><input id="password" name="password" type="password" placeholder="Введите пароль" required autocomplete="current-password"></div>
      <div class="login-error" id="loginError"></div><button class="primary-btn" style="width:100%" type="submit">Войти в дневник →</button>
    </form>
    <div class="demo-accounts"><b>ДЕМО-ДОСТУПЫ (пароль у всех demo123)</b><p>Ученик: <b>student</b> · Учитель: <b>teacher</b><br>Родитель: <b>parent</b> · Администратор: <b>admin</b></p></div>
  </section></main>`;
  document.getElementById("loginForm").addEventListener("submit",e=>{
    e.preventDefault();
    const form=new FormData(e.currentTarget);
    const user=db.users.find(u=>u.login===form.get("login").trim() && u.password===form.get("password"));
    if(!user){document.getElementById("loginError").textContent="Неверный логин или пароль. Попробуйте demo123.";return;}
    currentUser=user; renderApp();
  });
}

function renderApp(){
  document.body.innerHTML = appTemplate;
  // Restore event bindings after the shell is mounted.
  document.getElementById("sidebarName").textContent=currentUser.name;
  document.getElementById("sidebarRole").textContent=roleNames[currentUser.role];
  document.getElementById("sidebarAvatar").textContent=initials(currentUser.name);
  document.getElementById("topAvatar").textContent=initials(currentUser.name);
  document.getElementById("topName").textContent=currentUser.name;
  document.getElementById("todayLabel").textContent=new Date().toLocaleDateString("ru-RU",{weekday:"short",day:"numeric",month:"long"});
  document.querySelectorAll(".admin-only").forEach(el=>el.classList.toggle("hidden",currentUser.role!=="admin"));
  document.querySelectorAll(".nav-link").forEach(btn=>btn.addEventListener("click",()=>navigate(btn.dataset.view)));
  document.getElementById("mobileMenu").addEventListener("click",()=>document.getElementById("sidebar").classList.toggle("open"));
  document.getElementById("profileButton").addEventListener("click",logout);
  document.getElementById("notifications").addEventListener("click",()=>toast("Новых уведомлений нет"));
  document.getElementById("closeModal").addEventListener("click",closeModal);
  document.getElementById("modalBackdrop").addEventListener("click",e=>{if(e.target.id==="modalBackdrop")closeModal();});
  navigate("overview");
}
const appTemplate = `
<div class="app-shell">
<aside class="sidebar" id="sidebar">
  <a class="brand" href="#"><span class="brand-mark">Д</span><span>Дневник<span class="brand-dot">.</span></span></a>
  <div class="school-label">ШКОЛЬНЫЙ ПОРТАЛ</div>
  <nav class="nav"><button class="nav-link active" data-view="overview"><span>▦</span> Обзор</button><button class="nav-link" data-view="grades"><span>★</span> Оценки</button><button class="nav-link" data-view="homework"><span>▤</span> Домашние задания</button><button class="nav-link" data-view="schedule"><span>▦</span> Расписание</button><button class="nav-link" data-view="attendance"><span>✓</span> Посещаемость</button><button class="nav-link admin-only" data-view="users"><span>♙</span> Пользователи</button></nav>
  <div class="sidebar-bottom"><div class="help-card"><div class="help-icon">?</div><b>Нужна помощь?</b><p>Это демонстрационная версия дневника.</p></div><button class="profile-mini" id="profileButton"><span class="avatar" id="sidebarAvatar">У</span><span class="profile-mini-text"><b id="sidebarName">Пользователь</b><small id="sidebarRole">Роль</small></span><span class="more">↪</span></button></div>
</aside>
<main class="main"><header class="topbar"><button class="mobile-menu" id="mobileMenu">☰</button><div class="breadcrumb">Школа <span>/</span> <b id="crumb">Обзор</b></div><div class="top-actions"><span class="today" id="todayLabel"></span><button class="icon-button" id="notifications">♧<i></i></button><div class="user-chip"><span class="avatar small" id="topAvatar">У</span><b id="topName">Пользователь</b></div></div></header><section class="content"><div id="pageContent"></div><footer>© 2026 Дневник. Демонстрационный учебный проект.</footer></section></main></div>
<div class="modal-backdrop hidden" id="modalBackdrop"><section class="modal" role="dialog" aria-modal="true"><div class="modal-head"><div><span class="eyebrow">ДЕЙСТВИЕ</span><h2 id="modalTitle">Добавить запись</h2></div><button class="close-button" id="closeModal">×</button></div><form id="entryForm"></form></section></div><div class="toast" id="toast"></div>`;

function navigate(view){
  if(view==="users" && currentUser.role!=="admin") view="overview";
  currentView=view;
  document.querySelectorAll(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
  document.getElementById("crumb").textContent=viewNames[view];
  renderView();
  document.getElementById("sidebar").classList.remove("open");
}
function heading(title,subtitle,action=""){
 return `<div class="page-heading"><div><div class="eyebrow">ЛИЧНЫЙ КАБИНЕТ · ${roleNames[currentUser.role].toUpperCase()}</div><h1>${title}</h1><p>${subtitle}</p></div>${action}</div>`;
}
function stat(label,value,note,icon){return `<div class="stat-card"><div class="stat-top"><span>${label}</span><span class="stat-icon">${icon}</span></div><div class="stat-value">${value}</div><div class="stat-note">${note}</div></div>`;}
function gradeClass(v){return v>=5?"":v>=4?"mid":"low";}
function renderView(){
 const target=document.getElementById("pageContent");
 if(currentView==="overview") target.innerHTML=overviewView();
 if(currentView==="grades") target.innerHTML=gradesView();
 if(currentView==="homework") target.innerHTML=homeworkView();
 if(currentView==="schedule") target.innerHTML=scheduleView();
 if(currentView==="attendance") target.innerHTML=attendanceView();
 if(currentView==="users") target.innerHTML=usersView();
 bindPageActions();
}
function overviewView(){
 const sid=studentIdForUser(currentUser), gs=db.grades.filter(g=>g.studentId===sid), hw=db.homework;
 const avg=average(gs), next=hw.filter(x=>x.status!=="Сдано").length;
 const title=currentUser.role==="teacher"?"Добро пожаловать, Иван!":currentUser.role==="admin"?"Панель администратора":currentUser.role==="parent"?"Здравствуйте!":"Добро пожаловать, Анна!";
 const sub=currentUser.role==="parent"?"Здесь собрана актуальная информация об успеваемости вашего ребёнка.":"Здесь собрана главная информация об учебном процессе.";
 let action=(currentUser.role==="teacher"||currentUser.role==="admin")?'<button class="primary-btn" data-action="add-grade">＋ Выставить оценку</button>':"";
 return `${heading(title,sub,action)}
 <div class="stats-grid">${stat("Средний балл",avg,"По всем предметам","★")}${stat("Всего оценок",gs.length,"За текущий период","▤")}${stat("Домашние задания",next,"Ожидают выполнения","✎")}${stat("Посещаемость","96%","За последние 30 дней","✓")}</div>
 <div class="dashboard-grid"><div>
 <section class="panel"><div class="panel-head"><h3>Последние оценки</h3><a data-go="grades">Все оценки →</a></div>${gradeRows(gs.slice().sort((a,b)=>b.date.localeCompare(a.date)).slice(0,5))}</section>
 <section class="panel"><div class="panel-head"><h3>Домашние задания</h3><a data-go="homework">Все задания →</a></div>${taskRows(hw.slice(0,3))}</section>
 </div><div>
 <section class="panel"><div class="panel-head"><h3>Расписание на день</h3><a data-go="schedule">Подробнее →</a></div>${scheduleItems(db.schedule.slice(0,4))}</section>
 <section class="panel"><div class="panel-head"><h3>Объявления школы</h3></div><div class="task-list"><div class="task-item"><span class="task-bullet"></span><div><b>Началась новая учебная неделя</b><small>Проверьте расписание и домашние задания.</small></div></div><div class="task-item"><span class="task-bullet" style="background:#e9a84f"></span><div><b>Родительское собрание</b><small>Пятница, 18:00 · Кабинет 205</small></div></div></div></section>
 </div></div>`;
}
function gradeRows(list){
 if(!list.length)return '<div class="empty">Оценок пока нет</div>';
 return `<div class="grade-list">${list.map(g=>`<div class="grade-row"><div><div class="subject">${esc(g.subject)}</div><div class="subtext">${esc(g.topic)}</div></div><div class="muted">${fmtDate(g.date)}</div><span class="grade ${gradeClass(g.value)}">${g.value}</span><span class="muted">${esc(studentName(g.studentId))}</span></div>`).join("")}</div>`;
}
function taskRows(list){
 if(!list.length)return '<div class="empty">Заданий пока нет</div>';
 return `<div class="task-list">${list.map(t=>`<div class="task-item"><span class="task-bullet"></span><div><b>${esc(t.subject)} — ${esc(t.title)}</b><small>Срок: ${fmtDate(t.due)} · ${esc(t.status)}</small></div></div>`).join("")}</div>`;
}
function scheduleItems(list){
 if(!list.length)return '<div class="empty">Расписание пока не заполнено</div>';
 return `<div class="schedule-list">${list.map(s=>`<div class="schedule-item"><span class="time">${esc(s.time)}</span><span class="schedule-line"></span><div class="schedule-info"><b>${esc(s.subject)}</b><small>Кабинет ${esc(s.room)} · ${esc(s.teacher)}</small></div></div>`).join("")}</div>`;
}
function gradesView(){
 const sid=studentIdForUser(currentUser), canEdit=["teacher","admin"].includes(currentUser.role);
 let list=db.grades.filter(g=>currentUser.role==="admin"||g.studentId===sid);
 return `${heading("Журнал оценок","Успеваемость по учебным предметам",canEdit?'<button class="primary-btn" data-action="add-grade">＋ Добавить оценку</button>':"")}
 <section class="panel"><div class="panel-head"><h3>Оценки ${currentUser.role==="parent"?"ребёнка":""}</h3><span class="pill">${list.length} записей</span></div><div class="table-wrap"><table><thead><tr><th>Предмет</th><th>Ученик</th><th>Тема</th><th>Дата</th><th>Оценка</th></tr></thead><tbody>${list.map(g=>`<tr><td><b>${esc(g.subject)}</b></td><td>${esc(studentName(g.studentId))}</td><td>${esc(g.topic)}</td><td>${fmtDate(g.date)}</td><td><span class="grade ${gradeClass(g.value)}">${g.value}</span></td></tr>`).join("")||'<tr><td colspan="5" class="empty">Записей пока нет</td></tr>'}</tbody></table></div></section>`;
}
function homeworkView(){
 const canEdit=["teacher","admin"].includes(currentUser.role);
 return `${heading("Домашние задания","Список заданий и сроки выполнения",canEdit?'<button class="primary-btn" data-action="add-homework">＋ Добавить задание</button>':"")}
 <section class="panel"><div class="panel-head"><h3>Все задания</h3><span class="pill">${db.homework.length} заданий</span></div><div class="table-wrap"><table><thead><tr><th>Предмет</th><th>Задание</th><th>Срок сдачи</th><th>Статус</th>${canEdit?"<th></th>":""}</tr></thead><tbody>${db.homework.map(t=>`<tr><td><b>${esc(t.subject)}</b></td><td>${esc(t.title)}</td><td>${fmtDate(t.due)}</td><td><span class="pill ${t.status==="Сдано"?"green":t.status==="В работе"?"orange":""}">${esc(t.status)}</span></td>${canEdit?`<td><button class="text-link" data-delete-homework="${t.id}">Удалить</button></td>`:""}</tr>`).join("")||'<tr><td colspan="5" class="empty">Заданий пока нет</td></tr>'}</tbody></table></div></section>`;
}
function scheduleView(){
 return `${heading("Расписание уроков","Понедельник · Учебная неделя")}<section class="panel"><div class="panel-head"><h3>Расписание 8А</h3><span class="pill">5 уроков</span></div><div class="table-wrap"><table><thead><tr><th>Время</th><th>Предмет</th><th>Преподаватель</th><th>Кабинет</th></tr></thead><tbody>${db.schedule.map(s=>`<tr><td><b>${esc(s.time)}</b></td><td>${esc(s.subject)}</td><td>${esc(s.teacher)}</td><td>${esc(s.room)}</td></tr>`).join("")}</tbody></table></div></section>`;
}
function attendanceView(){
 const sid=studentIdForUser(currentUser);
 return `${heading("Посещаемость","Учёт посещения занятий")}<section class="panel"><div class="panel-head"><h3>История посещений</h3><span class="pill green">96% посещаемости</span></div><div class="table-wrap"><table><thead><tr><th>Дата</th><th>Предмет</th><th>Статус</th></tr></thead><tbody>${db.attendance.map(a=>`<tr><td>${fmtDate(a.date)}</td><td>${esc(a.subject)}</td><td><span class="pill ${a.status==="Присутствовал"?"green":"orange"}">${esc(a.status)}</span></td></tr>`).join("")}</tbody></table></div></section>`;
}
function usersView(){
 return `${heading("Пользователи","Демонстрационные учётные записи")}<section class="panel"><div class="panel-head"><h3>Все пользователи</h3><span class="pill">${db.users.length} аккаунта</span></div><div class="table-wrap"><table><thead><tr><th>Имя</th><th>Логин</th><th>Роль</th><th>Класс / предмет</th></tr></thead><tbody>${db.users.map(u=>`<tr><td><b>${esc(u.name)}</b></td><td>${esc(u.login)}</td><td><span class="pill">${roleNames[u.role]}</span></td><td>${esc(u.className||u.subject||"—")}</td></tr>`).join("")}</tbody></table></div><p class="muted" style="font-size:10px">В демонстрационной версии администратор может просматривать учётные записи. Создание пользователей не подключено.</p></section>`;
}
function bindPageActions(){
 document.querySelectorAll("[data-go]").forEach(el=>el.addEventListener("click",()=>navigate(el.dataset.go)));
 document.querySelectorAll("[data-action]").forEach(el=>el.addEventListener("click",()=>openEntry(el.dataset.action)));
 document.querySelectorAll("[data-delete-homework]").forEach(el=>el.addEventListener("click",()=>{db.homework=db.homework.filter(x=>x.id!==Number(el.dataset.deleteHomework));saveDB();renderView();toast("Задание удалено");}));
}
function openEntry(type){
 const form=document.getElementById("entryForm"), title=document.getElementById("modalTitle");
 if(type==="add-grade"){
  title.textContent="Выставить оценку";
  const students=db.users.filter(u=>u.role==="student");
  form.innerHTML=`<div class="field"><label>Ученик</label><select name="studentId">${students.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join("")}</select></div><div class="field"><label>Предмет</label><select name="subject">${["Математика","Русский язык","История","Физика","Английский язык","Биология","География"].map(x=>`<option>${x}</option>`).join("")}</select></div><div class="field"><label>Тема урока</label><input name="topic" placeholder="Например, Контрольная работа" required></div><div class="field"><label>Оценка</label><select name="value"><option>5</option><option>4</option><option>3</option><option>2</option></select></div><div class="field"><label>Дата</label><input type="date" name="date" value="${new Date().toISOString().slice(0,10)}" required></div><div class="modal-actions"><button type="button" class="secondary-btn" data-cancel>Отмена</button><button class="primary-btn">Сохранить оценку</button></div>`;
 }else{
  title.textContent="Новое домашнее задание";
  form.innerHTML=`<div class="field"><label>Предмет</label><select name="subject">${["Математика","Русский язык","История","Физика","Английский язык","Биология","География"].map(x=>`<option>${x}</option>`).join("")}</select></div><div class="field"><label>Описание задания</label><input name="title" placeholder="Что нужно сделать?" required></div><div class="field"><label>Срок сдачи</label><input type="date" name="due" required></div><div class="modal-actions"><button type="button" class="secondary-btn" data-cancel>Отмена</button><button class="primary-btn">Опубликовать</button></div>`;
 }
 form.querySelector("[data-cancel]").addEventListener("click",closeModal);
 form.onsubmit=e=>{
  e.preventDefault();const data=Object.fromEntries(new FormData(form).entries());
  if(type==="add-grade")db.grades.unshift({id:Date.now(),studentId:Number(data.studentId),subject:data.subject,topic:data.topic,value:Number(data.value),date:data.date});
  else db.homework.unshift({id:Date.now(),subject:data.subject,title:data.title,due:data.due,status:"Не начато"});
  saveDB();closeModal();renderView();toast(type==="add-grade"?"Оценка сохранена":"Задание опубликовано");
 };
 document.getElementById("modalBackdrop").classList.remove("hidden");
}
function closeModal(){document.getElementById("modalBackdrop").classList.add("hidden");}
let toastTimer;
function toast(message){const el=document.getElementById("toast");el.textContent=message;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),2400);}
function logout(){currentUser=null;showLogin();}
function start(){document.body.innerHTML=appTemplate;showLogin();}
start();
